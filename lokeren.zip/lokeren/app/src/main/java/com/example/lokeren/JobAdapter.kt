package com.example.lokeren

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Filter
import android.widget.Filterable
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale

class JobAdapter(
    private val context: Context,
    private var jobList: ArrayList<Job>
) : RecyclerView.Adapter<JobAdapter.JobViewHolder>(), Filterable {

    private var jobListFull: ArrayList<Job> = ArrayList(jobList)

    class JobViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val cardJob: CardView = itemView.findViewById(R.id.cardJob)
        val tvJobTitle: TextView = itemView.findViewById(R.id.tvJobTitle)
        val tvCompany: TextView = itemView.findViewById(R.id.tvCompany)
        val tvLocation: TextView = itemView.findViewById(R.id.tvLocation)
        val tvSalary: TextView = itemView.findViewById(R.id.tvSalary)
        val tvType: TextView = itemView.findViewById(R.id.tvType)
        val tvCategory: TextView = itemView.findViewById(R.id.tvCategory)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JobViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_job, parent, false)
        return JobViewHolder(view)
    }

    override fun onBindViewHolder(holder: JobViewHolder, position: Int) {
        val job = jobList[position]

        holder.tvJobTitle.text = job.title
        holder.tvCompany.text = job.company
        holder.tvLocation.text = job.location
        holder.tvSalary.text = job.salary
        holder.tvType.text = job.type
        holder.tvCategory.text = job.category

        holder.cardJob.setOnClickListener {
            val intent = Intent(context, DetailActivity::class.java)
            intent.putExtra("title", job.title)
            intent.putExtra("company", job.company)
            intent.putExtra("location", job.location)
            intent.putExtra("salary", job.salary)
            intent.putExtra("type", job.type)
            intent.putExtra("category", job.category)
            intent.putExtra("description", job.description)
            intent.putExtra("requirements", job.requirements)
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int = jobList.size

    override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(constraint: CharSequence?): FilterResults {
                val filteredList = ArrayList<Job>()

                if (constraint.isNullOrEmpty()) {
                    filteredList.addAll(jobListFull)
                } else {
                    val filterPattern = constraint.toString().lowercase(Locale.getDefault()).trim()

                    for (job in jobListFull) {
                        if (job.title.lowercase(Locale.getDefault()).contains(filterPattern) ||
                            job.company.lowercase(Locale.getDefault()).contains(filterPattern) ||
                            job.location.lowercase(Locale.getDefault()).contains(filterPattern) ||
                            job.category.lowercase(Locale.getDefault()).contains(filterPattern)
                        ) {
                            filteredList.add(job)
                        }
                    }
                }

                val results = FilterResults()
                results.values = filteredList
                return results
            }

            @Suppress("UNCHECKED_CAST")
            override fun publishResults(constraint: CharSequence?, results: FilterResults?) {
                jobList.clear()
                jobList.addAll(results?.values as ArrayList<Job>)
                notifyDataSetChanged()
            }
        }
    }

    fun filterByCategory(category: String) {
        if (category == "Semua") {
            jobList = ArrayList(jobListFull)
        } else {
            val filtered = jobListFull.filter { it.category.equals(category, ignoreCase = true) }
            jobList = ArrayList(filtered)
        }
        notifyDataSetChanged()
    }
}