package com.example.lokeren

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        supportActionBar?.title = "Detail Lowongan"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val tvDetailTitle = findViewById<TextView>(R.id.tvDetailTitle)
        val tvDetailCompany = findViewById<TextView>(R.id.tvDetailCompany)
        val tvDetailLocation = findViewById<TextView>(R.id.tvDetailLocation)
        val tvDetailSalary = findViewById<TextView>(R.id.tvDetailSalary)
        val tvDetailType = findViewById<TextView>(R.id.tvDetailType)
        val tvDetailCategory = findViewById<TextView>(R.id.tvDetailCategory)
        val tvDetailDescription = findViewById<TextView>(R.id.tvDetailDescription)
        val tvDetailRequirements = findViewById<TextView>(R.id.tvDetailRequirements)

        tvDetailTitle.text = intent.getStringExtra("title")
        tvDetailCompany.text = intent.getStringExtra("company")
        tvDetailLocation.text = "Lokasi: ${intent.getStringExtra("location")}"
        tvDetailSalary.text = "Gaji: ${intent.getStringExtra("salary")}"
        tvDetailType.text = "Tipe: ${intent.getStringExtra("type")}"
        tvDetailCategory.text = "Kategori: ${intent.getStringExtra("category")}"
        tvDetailDescription.text = intent.getStringExtra("description")
        tvDetailRequirements.text = intent.getStringExtra("requirements")
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}