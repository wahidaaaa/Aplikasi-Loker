package com.example.lokeren

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: JobAdapter
    private lateinit var etSearch: EditText

    private lateinit var chipSemua: TextView
    private lateinit var chipIT: TextView
    private lateinit var chipDesign: TextView
    private lateinit var chipMarketing: TextView
    private lateinit var chipAdmin: TextView

    private val jobList = arrayListOf(
        Job(
            "Android Developer",
            "PT Digital Nusantara",
            "Medan",
            "Rp 5.000.000 - Rp 8.000.000",
            "Full Time",
            "IT",
            "Membangun dan mengembangkan aplikasi Android berbasis Kotlin serta melakukan maintenance aplikasi.",
            "Minimal D3/S1 Teknik Informatika, menguasai Kotlin, memahami Android Studio dan API."
        ),
        Job(
            "UI/UX Designer",
            "Kreasi Visual Studio",
            "Jakarta",
            "Rp 4.500.000 - Rp 7.000.000",
            "Full Time",
            "Design",
            "Merancang tampilan antarmuka aplikasi dan website yang menarik dan mudah digunakan.",
            "Menguasai Figma/Adobe XD, memahami user flow dan wireframe."
        ),
        Job(
            "Digital Marketing Staff",
            "PT Maju Bersama",
            "Bandung",
            "Rp 4.000.000 - Rp 6.500.000",
            "Full Time",
            "Marketing",
            "Menjalankan kampanye digital marketing melalui social media dan ads.",
            "Berpengalaman di bidang digital marketing, memahami Meta Ads dan Google Ads."
        ),
        Job(
            "Admin Operasional",
            "CV Sukses Mandiri",
            "Pekanbaru",
            "Rp 3.500.000 - Rp 5.000.000",
            "Full Time",
            "Admin",
            "Mengelola data operasional, input laporan, dan koordinasi administrasi harian.",
            "Mahir Microsoft Office, teliti, dan mampu bekerja sama dalam tim."
        ),
        Job(
            "Frontend Developer",
            "PT Solusi Teknologi",
            "Yogyakarta",
            "Rp 5.500.000 - Rp 8.500.000",
            "Full Time",
            "IT",
            "Mengembangkan tampilan web dan mobile yang interaktif dan responsif.",
            "Menguasai HTML, CSS, JavaScript, dan framework frontend."
        ),
        Job(
            "Graphic Designer",
            "Studio Kreatif Indonesia",
            "Surabaya",
            "Rp 4.000.000 - Rp 6.000.000",
            "Contract",
            "Design",
            "Membuat desain konten promosi digital, poster, dan branding visual.",
            "Menguasai Photoshop, Illustrator, dan memiliki portofolio desain."
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        supportActionBar?.hide()

        window.statusBarColor = android.graphics.Color.parseColor("#1E3C72")

        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerViewJobs)
        etSearch = findViewById(R.id.etSearch)

        chipSemua = findViewById(R.id.chipSemua)
        chipIT = findViewById(R.id.chipIT)
        chipDesign = findViewById(R.id.chipDesign)
        chipMarketing = findViewById(R.id.chipMarketing)
        chipAdmin = findViewById(R.id.chipAdmin)

        adapter = JobAdapter(this, ArrayList(jobList))
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                adapter.filter.filter(s.toString())
            }

            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        chipSemua.setOnClickListener {
            setSelectedChip(chipSemua)
            adapter.filterByCategory("Semua")
        }

        chipIT.setOnClickListener {
            setSelectedChip(chipIT)
            adapter.filterByCategory("IT")
        }

        chipDesign.setOnClickListener {
            setSelectedChip(chipDesign)
            adapter.filterByCategory("Design")
        }

        chipMarketing.setOnClickListener {
            setSelectedChip(chipMarketing)
            adapter.filterByCategory("Marketing")
        }

        chipAdmin.setOnClickListener {
            setSelectedChip(chipAdmin)
            adapter.filterByCategory("Admin")
        }

        setSelectedChip(chipSemua)
    }

    private fun setSelectedChip(selectedChip: TextView) {
        val chips = listOf(chipSemua, chipIT, chipDesign, chipMarketing, chipAdmin)

        for (chip in chips) {
            chip.setBackgroundResource(R.drawable.bg_chip_unselected)
            chip.setTextColor(resources.getColor(android.R.color.black))
        }

        selectedChip.setBackgroundResource(R.drawable.bg_chip_selected)
        selectedChip.setTextColor(resources.getColor(android.R.color.white))
    }
}