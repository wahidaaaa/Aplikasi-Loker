package com.example.lokeren

data class Job(
    val title: String,
    val company: String,
    val location: String,
    val salary: String,
    val type: String,
    val category: String,
    val description: String,
    val requirements: String
)